<?php

//encryption

$secrets['encryption_key'] = 'abc34u3hhfsd89342k50-yfdjkgme4s8';