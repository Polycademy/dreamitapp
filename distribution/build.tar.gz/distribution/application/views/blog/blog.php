<script type="text/ng-template" id="blog.html">
	<div class="container">
		<p>This is the blog page</p>
	</div>
</script>