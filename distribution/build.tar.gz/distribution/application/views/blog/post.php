<script type="text/ng-template" id="post.html">
	<p>This is a specific blog.</p>
</script>