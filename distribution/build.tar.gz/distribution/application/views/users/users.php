<script type="text/ng-template" id="users.html">
	<div class="container">
		<p>This is the users page.</p>
	</div>
</script>