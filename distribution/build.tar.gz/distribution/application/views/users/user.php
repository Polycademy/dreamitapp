<script type="text/ng-template" id="user.html">
	<div class="container">
		<p>This is the singular user page.</p>
	</div>
</script>