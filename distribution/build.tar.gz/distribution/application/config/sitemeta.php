<?php

//Site Meta Data

$config['sitemeta'] = array(
	'title'						=> 'Dream it App',
	'desc'						=> 'Give your app ideas feedback!',
	'meta_desc'					=> 'Dream it App is a platform for app ideas to gain feedback and potentially get built.',
	'facebook'					=> 'https://www.facebook.com/Polycademy',
	'twitter'					=> 'https://twitter.com/Polycademy',
	'copyright'					=> '&copy; Dream it App 2013',
	'google_site_verification'	=> '',
	'google_analytics_key'		=> '',
);