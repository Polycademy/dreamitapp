define(['angular'], function(angular){

	'use strict';

	angular.module('Controllers')
		.controller('BlogCtrl', [
			'$scope',
			function($scope){
			}
		])
		.controller('PostCtrl', [
			'$scope',
			function($scope){
			}
		]);

});