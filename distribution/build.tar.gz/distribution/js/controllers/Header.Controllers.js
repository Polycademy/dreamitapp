define(['angular'], function(angular){

	'use strict';

	angular.module('Controllers')
		.controller('HeaderCtrl', [
			'$scope',
			function($scope){


			}
		]);

});